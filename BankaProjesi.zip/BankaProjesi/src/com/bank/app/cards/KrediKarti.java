package com.bank.app.cards;
import java.util.Random; // rastgele değerler ataması için Random kütüphanesini ekledim

public class KrediKarti {
    private String kartNo;
    private double guncelBorc;

    public KrediKarti(double limit, double borc){
        this.guncelBorc = borc;
        // Random kart no üretimi yapıyorum burada
        this.kartNo = "4444-" + (new Random().nextInt(9000) + 1000);
    }
    public double getGuncelBorc() {
        return guncelBorc;
    }
    public void setGuncelBorc(double b){
        this.guncelBorc = b;
    }

    @Override
    public String toString(){
        return "Kart: " + kartNo + " | Borc: " + guncelBorc + " TL ";
    }
}

package com.bank.app.people;

import java.util.ArrayList;
import java.util.Random;

/**
 * BankaPersoneli sınıfı, Kisi sınıfından miras alır.
 * UML diyagramına uygun olarak personelID ve musteriler listesini tutar.
 */
public class BankaPersoneli extends Kisi {
    private String personelID; // bankadaki personele ait benzersiz kimlik
    private ArrayList<Musteri> musteriler; // personelin sorumlu olduğu müşteri listesi

    public BankaPersoneli(String ad, String soyad, String email, int telefon) {
        super(ad, soyad, email, telefon);
        this.personelID = String.valueOf(new Random().nextInt(900000) + 100000); // otomatik ID üretimi
        this.musteriler = new ArrayList<>();
    }

    public String getPersonelID() {
        return personelID;
    }

    public void setPersonelID(String personelID) {
        this.personelID = personelID;
    }

    public ArrayList<Musteri> getMusteriler() {
        return musteriler;
    }

    public void setMusteriler(ArrayList<Musteri> musteriler) {
        this.musteriler = musteriler;
    }

    // Personelin sorumlu olduğu müşteriyi ekler.
    public void musteriEkle(Musteri musteri) {
        if (!musteriler.contains(musteri)) {
            musteriler.add(musteri);
            System.out.println("Musteri personel sorumluluguna eklendi: " + musteri);
        } else {
            System.out.println("Musteri zaten bu personelin sorumlulugunda.");
        }
    }

    // Personelin sorumlu olduğu müşteriyi listeden çıkarır.
    public void musteriSil(Musteri musteri) {
        if (musteriler.remove(musteri)) {
            System.out.println("Musteri personel listesinden cikarildi: " + musteri);
        } else {
            System.out.println("Musteri bu personelin sorumlulugunda degil.");
        }
    }

    @Override
    public String toString() {
        return super.toString() + " | Personel ID: " + personelID +
               " | Sorumlu Oldugu Musteri Sayisi: " + musteriler.size();
    }
}

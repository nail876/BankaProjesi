package com.bank.app.people; // Kisi sınfının paketi

public abstract class Kisi{
    private String ad, soyad, email;
    private int telefonNumarasi;
    
    // Kişilerin bilgilerini this metodu ile tanımladım
    public Kisi(String ad,String soyad, String email, int tel){
        this.ad = ad; this.soyad = soyad; this.email = email; this.telefonNumarasi = tel;

    }
    // getter metodları ile çağırıyorum
    public String getAd() {return ad;}
    public String getSoyad() {return soyad;}
}
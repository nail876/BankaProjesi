package com.bank.app.people;
import java.util.Random; // rastgele değerler ataması için Random kütüphanesini ekledim

// Musteri Kisi sınıfından miras aldı
public class Musteri extends Kisi {
    private String musteriNumarasi;

    public Musteri(String ad, String soyad, String email, int tel){
        super(ad,soyad,email,tel); // burada super metodu ile Kisi sınıfındaki atanan değerleri çektik
        // Random 6 haneli müşteri numarası üretimi
        this.musteriNumarasi = String.valueOf(new Random().nextInt(900000) + 100000);
    }

    @Override // Nesneyi yazdırdığımızda anlamsız kodlar çıkmasın
    public String toString(){
        return "Musteri: " + getAd() + " " + getSoyad() + " | No: " + musteriNumarasi;
    }
}

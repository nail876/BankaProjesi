package com.bank.app.people;

import com.bank.app.accounts.BankaHesabi;
import com.bank.app.accounts.VadesizHesap;
import com.bank.app.accounts.YatirimHesabi;
import com.bank.app.cards.KrediKarti;
import java.util.ArrayList;
import java.util.Random;

// Musteri Kisi sınıfından miras aldı
public class Musteri extends Kisi {
    private String musteriNumarasi; // müşteri numarası, her müşteri için benzersiz olmalı
    private ArrayList<BankaHesabi> hesaplar; // müşteriye ait hesap listesi
    private ArrayList<KrediKarti> krediKartlari; // müşteriye ait kredi kartı listesi

    public Musteri(String ad, String soyad, String email, int tel) {
        super(ad, soyad, email, tel); // üst sınıfın konstruktörü ile ortak kişi bilgilerini ayarla
        this.musteriNumarasi = String.valueOf(new Random().nextInt(900000) + 100000); // rastgele müşteri numarası
        this.hesaplar = new ArrayList<>();
        this.krediKartlari = new ArrayList<>();
    }

    public String getMusteriNumarasi() {
        return musteriNumarasi;
    }

    public ArrayList<BankaHesabi> getHesaplar() {
        return hesaplar;
    }

    public void setHesaplar(ArrayList<BankaHesabi> hesaplar) {
        this.hesaplar = hesaplar;
    }

    public ArrayList<KrediKarti> getKrediKartlari() {
        return krediKartlari;
    }

    public void setKrediKartlari(ArrayList<KrediKarti> krediKartlari) {
        this.krediKartlari = krediKartlari;
    }

    // Müşteriye yeni hesap ekleme.
    // Hesap türüne göre vadesiz veya yatırım hesabı oluşturur.
    public BankaHesabi hesapEkle(String hesapTuru, double bakiye) {
        BankaHesabi yeniHesap = null;
        if (hesapTuru.equalsIgnoreCase("vadesiz")) {
            yeniHesap = new VadesizHesap(bakiye);
        } else if (hesapTuru.equalsIgnoreCase("yatirim")) {
            yeniHesap = new YatirimHesabi(bakiye);
        } else {
            System.out.println("Hata: Gecersiz hesap turu = " + hesapTuru);
            return null;
        }

        hesaplar.add(yeniHesap);
        System.out.println("Hesap eklendi: " + yeniHesap);
        return yeniHesap;
    }

    public KrediKarti krediKartiEkle(double limit, double borc) {
        KrediKarti kart = new KrediKarti(limit, borc);
        krediKartlari.add(kart);
        System.out.println("Kredi karti eklendi: " + kart);
        return kart;
    }

    // Müşterinin hesabını silme işlemi.
    // Hesap bakiyesi 0 değilse silme izin vermez, bu müşteri güvenliği için gereklidir.
    public void hesapSil(BankaHesabi hesap) {
        if (hesap == null) {
            System.out.println("Hesap bulunamadi.");
            return;
        }
        if (!hesaplar.contains(hesap)) {
            System.out.println("Bu hesap size ait degil.");
            return;
        }
        if (hesap.getBakiye() > 0) {
            System.out.println("Lutfen oncelikle bakiyenizi baska bir hesaba aktariniz.");
        } else {
            hesaplar.remove(hesap);
            System.out.println("Hesap silindi: " + hesap);
        }
    }

    public void krediKartiSil(KrediKarti kart) {
        if (kart == null) {
            System.out.println("Kart bulunamadi.");
            return;
        }
        if (!krediKartlari.contains(kart)) {
            System.out.println("Bu kart size ait degil.");
            return;
        }
        if (kart.getGuncelBorc() == 0) {
            krediKartlari.remove(kart);
            System.out.println("Kredi karti silindi: " + kart);
        } else {
            System.out.println("Lutfen oncelikle borc odemesi yapiniz.");
        }
    }

    @Override // Nesneyi yazdırdığımızda anlamsız kodlar çıkmasın
    public String toString() {
        return "Musteri: " + getAd() + " " + getSoyad() + " | No: " + musteriNumarasi +
               " | Hesap Sayisi: " + hesaplar.size() + " | Kart Sayisi: " + krediKartlari.size();
    }
}

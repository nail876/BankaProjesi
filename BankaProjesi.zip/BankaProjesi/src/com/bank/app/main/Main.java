package com.bank.app.main;

import com.bank.app.accounts.BankaHesabi;
import com.bank.app.accounts.VadesizHesap;
import com.bank.app.accounts.YatirimHesabi;
import com.bank.app.cards.KrediKarti;
import com.bank.app.people.BankaPersoneli;
import com.bank.app.people.Musteri;
import com.bank.app.service.BankaService;

public class Main {
    public static void main(String[] args) {
        // Uygulama başlangıcı, test senaryosu için basit bir banka akışı hazırlanıyor.
        System.out.println("--- BTU BANKA TEST ---");

        // Banka service sınıfı, uygulamanın iş mantığını ayrı bir katmanda toplar.
        BankaService service = new BankaService();

        // Müşteri oluşturma: uygulamada kullanılacak gerçek müşteri nesnesi.
        Musteri musteri = service.musteriOlustur("Nail", "Onur", "mail@btu.edu.tr", 12345);

        // Banka personeli oluşturma ve müşteriyi personelin sorumluluğuna ekleme.
        BankaPersoneli personel = service.personelOlustur("Ayse", "Yilmaz", "ayse@btu.edu.tr", 54321);
        personel.musteriEkle(musteri);

        // Müşteri adına iki farklı hesap açma: vadesiz ve yatırım.
        VadesizHesap vadesiz = (VadesizHesap) service.hesapAc(musteri, "vadesiz", 1000.0);
        YatirimHesabi yatirim = (YatirimHesabi) service.hesapAc(musteri, "yatirim", 500.0);

        // Yatırım hesabına para yatırma işlemi.
        service.paraYatir(yatirim, 300.0);

        // Hesaplar arası para transferi testi.
        service.hesaplarArasiTransfer(vadesiz, yatirim, 200.0);

        // Müşteriye bir kredi kartı tanımlama ve borç ödeme.
        KrediKarti kart = service.krediKartiTanimla(musteri, 10000.0, 800.0);
        service.krediKartiBorcOdeme(vadesiz, kart, 500.0);

        // Hesap silme senaryosu: bakiye sıfır olmayan hesabı silme denemesi.
        System.out.println("\n--- Hesap Silme Testi ---");
        service.hesapSil(musteri, vadesiz);

        // Bakiye sıfır olan yeni bir hesap açıp silme.
        BankaHesabi sifirBakiyeliHesap = service.hesapAc(musteri, "vadesiz", 0.0);
        service.hesapSil(musteri, sifirBakiyeliHesap);

        // Kredi kartı silme senaryosu: önce silme hatası, sonra borç ödeme ve başarılı silme.
        System.out.println("\n--- Kredi Kartı Silme Testi ---");
        service.krediKartiSil(musteri, kart);
        service.krediKartiBorcOdeme(vadesiz, kart, 300.0);
        service.krediKartiSil(musteri, kart);

        // Test sonrası son durum bilgilerini gösterme.
        System.out.println("\n--- SON DURUM ---");
        System.out.println(musteri);
        System.out.println(personel);
        System.out.println("--- TEST BASARILI ---");
    }
}
package com.bank.app.main;
import com.bank.app.people.Musteri;
import com.bank.app.accounts.*;
import com.bank.app.cards.KrediKarti;

public class Main {
    public static void main(String[] args) {
        System.out.println("--- BTU BANKA TEST ---");
        Musteri nail = new Musteri("Nail Bugra", "Onur", "mail@btu.edu.tr", 12345);
        VadesizHesap v = new VadesizHesap(5000.0);
        YatirimHesabi y = new YatirimHesabi(1000.0);
        KrediKarti k = new KrediKarti(10000.0, 2000.0);

        System.out.println(nail); // Artik @ isareti cikmayacak!
        System.out.println("Baslangic Vadesiz: " + v);
        
        v.paraTransferi(y, 1000.0); // Yatirim hesabina transfer edildi
        v.krediKartiBorcOdeme(k, 500.0); // Kredi karti borcu ödendi
        
        System.out.println("Son Durum Vadesiz: " + v);
        System.out.println("Son Durum Yatirim: " + y);
        System.out.println("Son Durum Kart: " + k);
        System.out.println("--- TEST BASARILI ---");
    }
}
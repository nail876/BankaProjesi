package com.bank.app.accounts;

import java.util.Random;

public abstract class BankaHesabi {
    private String iban; // her hesap için benzersiz IBAN numarası
    private double bakiye; // hesaptaki mevcut bakiye

    public BankaHesabi(double bakiye) {
        this.bakiye = bakiye;
        this.iban = "TR" + (new Random().nextInt(900000) + 100000); // rastgele IBAN üretimi
    }

    public String getIban() {
        return iban;
    }

    public double getBakiye() {
        return bakiye;
    }

    public void setBakiye(double b) {
        this.bakiye = b;
    }

    @Override
    public String toString() {
        return "IBAN: " + iban + " | Bakiye: " + bakiye + " TL";
    }
}
package com.bank.app.accounts;
import java.util.Random; // rastgele değerler ataması için Random kütüphanesini ekledim

public abstract class BankaHesabi {
    private String iban;
    private double bakiye;

    public BankaHesabi(double bakiye) {
        this.bakiye = bakiye;
        // Random IBAN üretimi yapıyorum burada
        this.iban = "TR" + (new Random().nextInt(900000) + 100000);
    }
    public double getBakiye() { return bakiye; }
    public void setBakiye(double b) { this.bakiye = b; }

    @Override // IBAN ve bakiyeyi ekranda düzgün görmek için yazdım
    public String toString() {
        return "IBAN: " + iban + " | Bakiye: " + bakiye + " TL";
    }
}
package com.bank.app.accounts;
import com.bank.app.cards.KrediKarti;

// Banka hesabından super metodu ile bakiye verisini aldım
public class VadesizHesap extends BankaHesabi{
    public VadesizHesap(double bakiye){
        super(bakiye);
    }

    // Para transferi metodu (Ata sınıfı üzerinden polimorfizm yaptım)
    public void paraTransferi(BankaHesabi alici,double miktar){
        if (getBakiye() >= miktar){
            setBakiye(getBakiye() - miktar);
            alici.setBakiye(alici.getBakiye() + miktar);
           System.out.println(miktar + " TL transfer basarili. ");
        }else{
           System.out.println("HATA: Yetersiz bakiye ! Transfer yapilamadi.");
        }
    }

    // Kart borcu ödeme metodu yaptım burada
    public void krediKartiBorcOdeme(KrediKarti kart, double miktar){
        if (getBakiye() >= miktar){
            setBakiye(getBakiye() - miktar);
            kart.setGuncelBorc(kart.getGuncelBorc() - miktar);
            System.out.println("Kart borcu odendi. Odenen miktar: " + miktar);
        }else{
            System.out.println("HATA: Kart borcunu odemek icin vadesiz hesabinizda yeterli bakiye yok!");
        }
    }
}

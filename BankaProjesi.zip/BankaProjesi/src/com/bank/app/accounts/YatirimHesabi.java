package com.bank.app.accounts;

// YatirimHesabi sınıfı Banka hesabı sınıfından super metodu ile bakiye verisini çektim
public class YatirimHesabi extends BankaHesabi {
    public YatirimHesabi(double bakiye) {
        super(bakiye);
    }

    public void paraEkle(double miktar) {
        if (miktar <= 0) {
            System.out.println("Lutfen pozitif miktar giriniz.");
            return;
        }
        setBakiye(getBakiye() + miktar);
        System.out.println(miktar + " TL yatirim hesabina eklendi.");
    }

    public void paraCek(double miktar) {
        if (miktar <= 0) {
            System.out.println("Lutfen pozitif miktar giriniz.");
            return;
        }
        if (getBakiye() >= miktar) {
            setBakiye(getBakiye() - miktar);
            System.out.println(miktar + " TL yatirim hesabindan cekildi.");
        } else {
            System.out.println("HATA: Yetersiz bakiye, cekme islemi basarisiz.");
        }
    }
}

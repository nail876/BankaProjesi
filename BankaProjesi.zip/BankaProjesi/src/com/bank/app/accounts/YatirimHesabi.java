package com.bank.app.accounts;

// YatirimHesabi sınıfı Banka hesabı sınıfından super metodu ile bakiye verisini çektim
public class YatirimHesabi extends BankaHesabi {
    public YatirimHesabi(double bakiye) { 
        super(bakiye);
    }
}
